/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/I2C.h>


/* Driver configuration */
#include "ti_drivers_config.h"

#include <unistd.h>

/* Is used to create the various delays
 * used throughout the application
*/
void delay(int ms) {
    int secs = ms * 1000;
    usleep(secs);
}

/* Used to send messages to server */
#define DISPLAY(x) UART_write(uart, &output, x);

/* Declaration of the readTemp function  */
int16_t readTemp();
void GPIO_Setup();

// UART Global Variables
char output[64];
int bytesToSend;

// Driver Handles - Global variables
UART_Handle uart;

// Custom Global Variables
#define TRUE                1
#define FALSE               0

// Task related timers
#define NUM_OF_TASKS        3
#define UPD_TIMER           1000     // Period to wait before updating the LED and server
#define TMP_TIMER           500      // Period to wait before checking temperature
#define BTN_TIMER           200      // Period to wait before checking for button press
#define TICK_PERIOD         100      // Interval at which the system increments a ticket, GCD of three timers

/* Variables to hold information
 * about the system
*/
uint16_t currentTemp        = 0;                        // temperature output by the sensor
uint16_t setPoint           = 26;       // Temperature set by user
uint16_t maxTemp            = 0;                       // Temperature when the unit begins cooling
unsigned short resetTime    =  0;       // Ticks since last update
int runTasks                = FALSE;   // Signifies when tasks should be ran

/* Declaration of timer */
Timer_Handle timer0;

/* Message shown at the start of the program */
char welcomeMsg[128] = "Welcome to the SysTec Thermostat!!!\r\nOne button increases and the other decreases the set point of the thermostat.\r\n";

/* State tracks a button press and which button was pressed,
 * it signifies either an increase of decrease in set point
*/
enum buttonStates { INCREASE, DECREASE, NEUTRAL } buttonState;

/* State tracks the status of the unit and
 * if it is cooling, heating or off */
enum unitStates { COOLING = 2, HEATING = 1, OFF = 0 } unitState;

/* Function turns LED on */
void LED_ON() {GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);}
void LED_OFF() {GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);}

/* Declaration of functions used in timer callback,
 * if triggered
*/
void taskCheckButton();
void taskCheckTemp();
void taskUpdateSvr();

/* Individual tasks that are executed by the timer */
struct taskEntry {
    char            taskName[30];
    int             triggered;
    void            (*f)();
    short int       elapsedTime;
    short int       period;
};


// I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
char *id;
} sensors[3] = {
                { 0x48, 0x0000, "11X" },
                { 0x49, 0x0000, "116" },
                { 0x41, 0x0001, "006" }
};
uint8_t         txBuffer[1];
uint8_t         rxBuffer[2];
I2C_Transaction i2cTransaction;

// Driver Handles - Global variables
I2C_Handle i2c;
// Make sure you call initUART() before calling this function.
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;

    DISPLAY(printf("Initializing I2C Driver - "))

    // Init the driver
    I2C_init();

    // Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;

    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
        DISPLAY(printf("Failed\r\n"))
        while (1);
    }
    DISPLAY(printf("Passed\r\n"))

    // Boards were shipped with different sensors.
    // Welcome to the world of embedded systems.
    // Try to determine which sensor we have.
    // Scan through the possible sensor addresses
    /* Common I2C transaction setup */
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;

    found = false;
    for (i=0; i<3; ++i)
    {
        i2cTransaction.slaveAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;
        DISPLAY(printf("Is this %s? \r\n", sensors[i].id))
        if (I2C_transfer(i2c, &i2cTransaction))
        {
            DISPLAY(printf("Found"))
            found = true;
                break;
        }
        DISPLAY(printf("No"))
}

    if(found)
    {
        DISPLAY(printf("Detected TMP%s I2C address: %x\r\n", sensors[i].id, i2cTransaction.slaveAddress))
    }
    else
    {
        DISPLAY(printf("Temperature sensor not found, contact professor\r\n"))
    }
}

/* Function checks the sensor for the temperature,
 * it is called by the check temperature function
*/
int16_t readTemp(void)
{
    int j;
    int16_t temperature = 0;

    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction))
    {
        /*
        * Extract degrees C from the received data;
        * see TMP sensor datasheet
        */
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;

        /*
        * If the MSB is set '1', then we have a 2's complement
        * negative value which needs to be sign extended
        */
        if (rxBuffer[0] & 0x80)
        {
            temperature |= 0xF000;
        }
    }
    else
    {
        DISPLAY(printf("Error reading temperature sensor (%d)\r\n",i2cTransaction.status))
        DISPLAY(printf("Please power cycle your board by unplugging USB and plugging back in.\r\n"))
    }
    return temperature;
}

/* Initialization of the UART driver */
void initUART(void)
{
    UART_Params uartParams;

    // Init the driver
    UART_init();

    // Configure the driver
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    // Open the driver
    uart = UART_open(CONFIG_UART_0, &uartParams);

    if (uart == NULL) {
    /* UART_open() failed */
        while (1);
    }
}


/* Scheduler function checks for button
 * event, this is a state machine to
 * change desired temperature of the system
*/
void taskCheckButton() {
    switch(buttonState) {
        case INCREASE:
            setPoint += 1;
            buttonState = NEUTRAL;
            break;
        case DECREASE:
            setPoint -= 1;
            buttonState = NEUTRAL;
            break;
        case NEUTRAL:
            buttonState = NEUTRAL;
            break;
        default:
            buttonState = NEUTRAL;
            break;
    }
};

/* Function gets the state of the unit,
 * and then sets the unitState*/
void getUnitState() {
    currentTemp = readTemp();
    maxTemp = setPoint + 3;
    if (currentTemp >= maxTemp) {
        unitState = COOLING;
    }
    else if ( currentTemp < setPoint) {
        unitState = HEATING;
    } else {
        unitState = OFF;
    }
}

/* Scheduler task calls the
 * function to get the current
 * state of unit and performs
 * the action specified
*/
void taskCheckTemp() {
    getUnitState;
    switch(unitState) {
        case OFF:
            LED_OFF();
            unitState = OFF;
            break;
        case COOLING:
            LED_ON();
            delay(100);
            LED_OFF();
            break;
        case HEATING:
            LED_ON();
            break;
        default:
            LED_OFF();
            unitState = OFF;
            break;
    }
};

/* Scheduler function updates the
 * server with current stats
*/
void taskUpdateSvr() {
    uint16_t state;
    // Gets the count of the timer
    resetTime += Timer_getCount(timer0);

    /* Emulates sending the data to the server
     * by printing out the details of the thermostat
    */
    DISPLAY(printf("<%02d, %02d, %d, %04d>\r\n", currentTemp, setPoint, unitState, resetTime));
};

/* Declare the tasks for the unit, this dictates
 * what tasks are ran and how often */
struct taskEntry tasks[NUM_OF_TASKS] = {
    {"Check Button", FALSE, &taskCheckButton, 200, BTN_TIMER},
    {"Check Temperature", FALSE, &taskCheckTemp, 500, TMP_TIMER},
    {"Update Server", FALSE, &taskUpdateSvr, 1000, UPD_TIMER}
};

/* Timer callback which is called once the
 * period has expired, loops through each
 * task to determine if event should be triggered */
void TimerCallback(Timer_Handle handle, int_fast16_t status)
{
    int x;
    for (x = 0; x < NUM_OF_TASKS; x++) {
        if (tasks[x].elapsedTime >= tasks[x].period)
        {
            tasks[x].triggered = TRUE;
            tasks[x].elapsedTime = 0;
            runTasks = TRUE;
        }
        else
        {
            tasks[x].elapsedTime += TICK_PERIOD;

        }
    }

}

/* Declare the timer for the program */
void initTIMER(void) {
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 100000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = TimerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
    /* Failed to initialized timer */
    while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
    /* Failed to start timer */
    while (1) {}
    }
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void handleButtonCallback(uint_least8_t index)
{
    if (buttonState == NEUTRAL) {
        if (index == CONFIG_GPIO_BUTTON_0) {
            buttonState = INCREASE;
        } else if (index == CONFIG_GPIO_BUTTON_1) {
            buttonState = DECREASE;
        }
    }
}


/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();
    initUART();
    initTIMER();
    initI2C();

    buttonState = NEUTRAL;
    resetTime = 0;

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, handleButtonCallback);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_1, handleButtonCallback);


    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_1);

    /* Display the welcome message on run */
    DISPLAY(printf(welcomeMsg));

    while(TRUE) {
        /* Executes when runTasks is true */
        if (runTasks) {
           int i;
           /* Executes the task if the task is triggered */
           for (i = 0; i < NUM_OF_TASKS; i++) {
               if(tasks[i].triggered) {
                   tasks[i].f();
                   tasks[i].triggered = FALSE;
               }
           }
           runTasks = FALSE;
        }
    }
}
